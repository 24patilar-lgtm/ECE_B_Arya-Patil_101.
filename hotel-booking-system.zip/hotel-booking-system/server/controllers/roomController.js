const db = require("../database");

exports.getAllRooms = (req, res) => {

    db.all(
        "SELECT * FROM rooms ORDER BY room_number",
        [],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            res.json({
                success: true,
                data: rows
            });
        }
    );
};


exports.getRoomById = (req, res) => {

    db.get(
        "SELECT * FROM rooms WHERE id = ?",
        [req.params.id],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (!row) {
                return res.status(404).json({
                    success: false,
                    message: "Room not found"
                });
            }

            res.json({
                success: true,
                data: row
            });
        }
    );
};


exports.createRoom = (req, res) => {

    const {
        room_number,
        room_type,
        price,
        status
    } = req.body;

    db.run(
        `
        INSERT INTO rooms
        (room_number, room_type, price, status)
        VALUES (?, ?, ?, ?)
        `,
        [
            room_number,
            room_type,
            price,
            status || "Available"
        ],
        function(err) {

            if (err) {

                if (err.message.includes("UNIQUE")) {
                    return res.status(409).json({
                        success: false,
                        message: "Room number already exists"
                    });
                }

                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            res.status(201).json({
                success: true,
                message: "Room added successfully",
                data: {
                    id: this.lastID,
                    room_number,
                    room_type,
                    price,
                    status: status || "Available"
                }
            });
        }
    );
};


exports.updateRoom = (req, res) => {

    const {
        room_number,
        room_type,
        price,
        status
    } = req.body;

    db.run(
        `
        UPDATE rooms
        SET room_number = ?,
            room_type = ?,
            price = ?,
            status = ?
        WHERE id = ?
        `,
        [
            room_number,
            room_type,
            price,
            status,
            req.params.id
        ],
        function(err) {

            if (err) {

                if (err.message.includes("UNIQUE")) {
                    return res.status(409).json({
                        success: false,
                        message: "Room number already exists"
                    });
                }

                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Room not found"
                });
            }

            res.json({
                success: true,
                message: "Room updated successfully"
            });
        }
    );
};


exports.deleteRoom = (req, res) => {

    db.get(
        `
        SELECT COUNT(*) AS count
        FROM bookings
        WHERE room_id = ?
        AND status = 'Confirmed'
        `,
        [req.params.id],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (row.count > 0) {
                return res.status(409).json({
                    success: false,
                    message: "Cannot delete room with an active booking"
                });
            }

            db.run(
                "DELETE FROM rooms WHERE id = ?",
                [req.params.id],
                function(err) {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: err.message
                        });
                    }

                    if (this.changes === 0) {
                        return res.status(404).json({
                            success: false,
                            message: "Room not found"
                        });
                    }

                    res.json({
                        success: true,
                        message: "Room deleted successfully"
                    });
                }
            );
        }
    );
};


exports.searchRooms = (req, res) => {

    const {
        type,
        checkIn,
        checkOut
    } = req.query;

    if (!checkIn || !checkOut) {
        return res.status(400).json({
            success: false,
            message: "Check-in and check-out dates are required"
        });
    }

    const start = new Date(checkIn);
    const end = new Date(checkOut);

    if (
        isNaN(start) ||
        isNaN(end) ||
        end <= start
    ) {
        return res.status(400).json({
            success: false,
            message: "Invalid date range"
        });
    }

    let sql = `
        SELECT r.*
        FROM rooms r
        WHERE 1 = 1
    `;

    const params = [];

    if (type) {
        sql += " AND r.room_type = ?";
        params.push(type);
    }

    sql += `
        AND r.id NOT IN (
            SELECT b.room_id
            FROM bookings b
            WHERE b.status = 'Confirmed'
            AND b.check_in < ?
            AND b.check_out > ?
        )
        ORDER BY r.room_number
    `;

    params.push(checkOut, checkIn);

    db.all(sql, params, (err, rows) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }

        res.json({
            success: true,
            data: rows
        });
    });
};