const db = require("../database");

exports.getAllBookings = (req, res) => {

    const search = req.query.search || "";

    const sql = `
        SELECT
            b.*,
            r.room_number,
            r.room_type,
            r.price
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        WHERE
            b.guest_name LIKE ?
            OR CAST(b.id AS TEXT) LIKE ?
            OR r.room_number LIKE ?
        ORDER BY b.id DESC
    `;

    const value = `%${search}%`;

    db.all(
        sql,
        [value, value, value],
        (err, rows) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            res.json({
                success: true,
                data: rows
            });
        }
    );
};


exports.getBookingById = (req, res) => {

    db.get(
        `
        SELECT
            b.*,
            r.room_number,
            r.room_type,
            r.price
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        WHERE b.id = ?
        `,
        [req.params.id],
        (err, row) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (!row) {
                return res.status(404).json({
                    success: false,
                    message: "Booking not found"
                });
            }

            res.json({
                success: true,
                data: row
            });
        }
    );
};


exports.createBooking = (req, res) => {

    const {
        guest_name,
        guest_email,
        guest_phone,
        room_id,
        check_in,
        check_out
    } = req.body;

    db.get(
        "SELECT * FROM rooms WHERE id = ?",
        [room_id],
        (err, room) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (!room) {
                return res.status(404).json({
                    success: false,
                    message: "Room not found"
                });
            }

            const overlapQuery = `
                SELECT id
                FROM bookings
                WHERE room_id = ?
                AND status = 'Confirmed'
                AND check_in < ?
                AND check_out > ?
            `;

            db.get(
                overlapQuery,
                [room_id, check_out, check_in],
                (err, existing) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: err.message
                        });
                    }

                    if (existing) {
                        return res.status(409).json({
                            success: false,
                            message: "Room is already booked for the selected dates"
                        });
                    }

                    const checkInDate = new Date(check_in);
                    const checkOutDate = new Date(check_out);

                    const millisecondsPerDay =
                        1000 * 60 * 60 * 24;

                    const numberOfNights = Math.ceil(
                        (checkOutDate - checkInDate) /
                        millisecondsPerDay
                    );

                    const totalAmount =
                        numberOfNights * room.price;

                    db.run(
                        `
                        INSERT INTO bookings
                        (
                            guest_name,
                            guest_email,
                            guest_phone,
                            room_id,
                            check_in,
                            check_out,
                            status
                        )
                        VALUES (?, ?, ?, ?, ?, ?, 'Confirmed')
                        `,
                        [
                            guest_name,
                            guest_email,
                            guest_phone,
                            room_id,
                            check_in,
                            check_out
                        ],
                        function(err) {

                            if (err) {
                                return res.status(500).json({
                                    success: false,
                                    message: err.message
                                });
                            }

                            res.status(201).json({
                                success: true,
                                message: "Room booked successfully",
                                data: {
                                    id: this.lastID,
                                    guest_name,
                                    guest_email,
                                    guest_phone,
                                    room_id,
                                    check_in,
                                    check_out,
                                    numberOfNights,
                                    totalAmount,
                                    status: "Confirmed"
                                }
                            });
                        }
                    );
                }
            );
        }
    );
};


exports.cancelBooking = (req, res) => {

    db.run(
        `
        UPDATE bookings
        SET status = 'Cancelled'
        WHERE id = ?
        `,
        [req.params.id],
        function(err) {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Booking not found"
                });
            }

            res.json({
                success: true,
                message: "Booking cancelled successfully"
            });
        }
    );
};


exports.updateBooking = (req, res) => {

    const {
        guest_name,
        guest_email,
        guest_phone,
        check_in,
        check_out
    } = req.body;

    db.run(
        `
        UPDATE bookings
        SET guest_name = ?,
            guest_email = ?,
            guest_phone = ?,
            check_in = ?,
            check_out = ?
        WHERE id = ?
        `,
        [
            guest_name,
            guest_email,
            guest_phone,
            check_in,
            check_out,
            req.params.id
        ],
        function(err) {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Booking not found"
                });
            }

            res.json({
                success: true,
                message: "Booking updated successfully"
            });
        }
    );
};