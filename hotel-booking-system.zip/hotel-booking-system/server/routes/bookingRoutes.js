const express = require("express");

const router = express.Router();

const bookingController =
    require("../controllers/bookingController");

const {
    validateBooking
} = require("../middleware/validation");


router.get("/", bookingController.getAllBookings);

router.get("/:id", bookingController.getBookingById);

router.post(
    "/",
    validateBooking,
    bookingController.createBooking
);

router.put(
    "/:id",
    validateBooking,
    bookingController.updateBooking
);

router.post(
    "/:id/cancel",
    bookingController.cancelBooking
);

router.delete(
    "/:id",
    bookingController.cancelBooking
);

module.exports = router;