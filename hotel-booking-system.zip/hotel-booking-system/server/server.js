require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");

const db = require("./database");

const roomRoutes = require("./routes/roomRoutes");
const bookingRoutes = require("./routes/bookingRoutes");

const app = express();

const PORT = process.env.PORT || 5000;


// ===============================
// Middleware
// ===============================

app.use(cors());

app.use(express.json());


// ===============================
// API Routes
// ===============================

app.use("/api/rooms", roomRoutes);

app.use("/api/bookings", bookingRoutes);


// ===============================
// Dashboard Statistics
// ===============================

app.get("/api/dashboard/stats", (req, res) => {

    const queries = {

        totalRooms: `
            SELECT COUNT(*) AS count
            FROM rooms
        `,

        availableRooms: `
            SELECT COUNT(*) AS count
            FROM rooms
            WHERE status = 'Available'
        `,

        bookedRooms: `
            SELECT COUNT(DISTINCT room_id) AS count
            FROM bookings
            WHERE status = 'Confirmed'
        `,

        totalBookings: `
            SELECT COUNT(*) AS count
            FROM bookings
        `,

        cancelledBookings: `
            SELECT COUNT(*) AS count
            FROM bookings
            WHERE status = 'Cancelled'
        `
    };


    // Total rooms
    db.get(queries.totalRooms, [], (err, total) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: err.message
            });
        }


        // Available rooms
        db.get(queries.availableRooms, [], (err, available) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }


            // Booked rooms
            db.get(queries.bookedRooms, [], (err, booked) => {

                if (err) {
                    return res.status(500).json({
                        success: false,
                        message: err.message
                    });
                }


                // Total bookings
                db.get(queries.totalBookings, [], (err, bookings) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: err.message
                        });
                    }


                    // Cancelled bookings
                    db.get(
                        queries.cancelledBookings,
                        [],
                        (err, cancelled) => {

                            if (err) {
                                return res.status(500).json({
                                    success: false,
                                    message: err.message
                                });
                            }


                            // Send response
                            res.json({
                                success: true,

                                data: {
                                    totalRooms: total.count,
                                    availableRooms: available.count,
                                    bookedRooms: booked.count,
                                    totalBookings: bookings.count,
                                    cancelledBookings: cancelled.count
                                }
                            });

                        }
                    );

                });

            });

        });

    });

});


// ===============================
// Serve Frontend
// ===============================

app.use(
    express.static(
        path.join(__dirname, "..", "public")
    )
);


// ===============================
// Default Route
// ===============================

app.get("/{*splat}", (req, res) => {

    res.sendFile(
        path.join(
            __dirname,
            "..",
            "public",
            "index.html"
        )
    );

});


// ===============================
// Start Server
// ===============================

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});