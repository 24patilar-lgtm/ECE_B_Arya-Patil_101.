const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const dbPath = path.join(__dirname, "..", "hotel.db");

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error("Database connection failed:", err.message);
    } else {
        console.log("Connected to SQLite database.");
    }
});

db.serialize(() => {

    db.run(`
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_number TEXT UNIQUE NOT NULL,
            room_type TEXT NOT NULL,
            price REAL NOT NULL,
            status TEXT DEFAULT 'Available'
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guest_name TEXT NOT NULL,
            guest_email TEXT NOT NULL,
            guest_phone TEXT NOT NULL,
            room_id INTEGER NOT NULL,
            check_in DATE NOT NULL,
            check_out DATE NOT NULL,
            status TEXT DEFAULT 'Confirmed',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(room_id) REFERENCES rooms(id)
        )
    `);

    db.get("SELECT COUNT(*) AS count FROM rooms", (err, row) => {

        if (err) {
            console.error(err.message);
            return;
        }

        if (row.count === 0) {

            const rooms = [
                ["101", "Single", 1500],
                ["102", "Double", 2200],
                ["103", "Deluxe", 3000],
                ["104", "Suite", 5000],
                ["105", "Deluxe", 3200],
                ["106", "Double", 2400]
            ];

            const stmt = db.prepare(`
                INSERT INTO rooms
                (room_number, room_type, price, status)
                VALUES (?, ?, ?, 'Available')
            `);

            rooms.forEach(room => {
                stmt.run(room);
            });

            stmt.finalize();

            console.log("Sample rooms inserted.");
        }
    });
});

module.exports = db;