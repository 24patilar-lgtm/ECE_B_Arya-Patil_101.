const roomTypes = ["Single", "Double", "Deluxe", "Suite"];

function validateRoom(req, res, next) {

    const {
        room_number,
        room_type,
        price,
        status
    } = req.body;

    if (!room_number || !room_number.toString().trim()) {
        return res.status(400).json({
            success: false,
            message: "Room number is required"
        });
    }

    if (!roomTypes.includes(room_type)) {
        return res.status(400).json({
            success: false,
            message: "Invalid room type"
        });
    }

    if (price === undefined || isNaN(price) || Number(price) < 0) {
        return res.status(400).json({
            success: false,
            message: "Price must be greater than or equal to 0"
        });
    }

    if (
        status !== undefined &&
        !["Available", "Booked"].includes(status)
    ) {
        return res.status(400).json({
            success: false,
            message: "Invalid room status"
        });
    }

    next();
}

function validateBooking(req, res, next) {

    const {
        guest_name,
        guest_email,
        guest_phone,
        room_id,
        check_in,
        check_out
    } = req.body;

    if (!guest_name || !guest_name.trim()) {
        return res.status(400).json({
            success: false,
            message: "Guest name is required"
        });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!guest_email || !emailRegex.test(guest_email)) {
        return res.status(400).json({
            success: false,
            message: "Invalid email address"
        });
    }

    const phoneRegex = /^[0-9]{10}$/;

    if (!guest_phone || !phoneRegex.test(guest_phone)) {
        return res.status(400).json({
            success: false,
            message: "Phone number must contain 10 digits"
        });
    }

    if (!room_id) {
        return res.status(400).json({
            success: false,
            message: "Room ID is required"
        });
    }

    const checkInDate = new Date(check_in);
    const checkOutDate = new Date(check_out);

    if (isNaN(checkInDate) || isNaN(checkOutDate)) {
        return res.status(400).json({
            success: false,
            message: "Invalid booking dates"
        });
    }

    if (checkOutDate <= checkInDate) {
        return res.status(400).json({
            success: false,
            message: "Check-out date must be after check-in date"
        });
    }

    next();
}

module.exports = {
    validateRoom,
    validateBooking
};