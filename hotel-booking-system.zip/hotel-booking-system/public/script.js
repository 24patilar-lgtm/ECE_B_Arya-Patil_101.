let rooms = [];


// ===============================
// NAVIGATION
// ===============================

function showSection(sectionId) {

    document
        .querySelectorAll(".section")
        .forEach(section => {
            section.classList.add("hidden");
        });

    document
        .getElementById(sectionId)
        .classList.remove("hidden");

    if (sectionId === "dashboard") {
        loadDashboard();
    }

    if (sectionId === "rooms") {
        loadRooms();
    }

    if (sectionId === "booking") {
        loadRoomOptions();
    }

    if (sectionId === "bookings") {
        loadBookings();
    }
}


// ===============================
// NOTIFICATION
// ===============================

function showNotification(message) {

    const notification =
        document.getElementById("notification");

    notification.textContent = message;

    notification.style.display = "block";

    setTimeout(() => {
        notification.style.display = "none";
    }, 3000);
}


// ===============================
// DASHBOARD
// ===============================

async function loadDashboard() {

    const response =
        await fetch("/api/dashboard/stats");

    const result =
        await response.json();

    if (!result.success) {
        showNotification(result.message);
        return;
    }

    document.getElementById("totalRooms")
        .textContent = result.data.totalRooms;

    document.getElementById("availableRooms")
        .textContent = result.data.availableRooms;

    document.getElementById("bookedRooms")
        .textContent = result.data.bookedRooms;

    document.getElementById("totalBookings")
        .textContent = result.data.totalBookings;

    document.getElementById("cancelledBookings")
        .textContent = result.data.cancelledBookings;
}


// ===============================
// LOAD ROOMS
// ===============================

async function loadRooms() {

    const response =
        await fetch("/api/rooms");

    const result =
        await response.json();

    if (!result.success) {
        showNotification(result.message);
        return;
    }

    rooms = result.data;

    displayRooms(rooms);
}


function displayRooms(data) {

    const table =
        document.getElementById("roomTable");

    table.innerHTML = "";

    data.forEach(room => {

        table.innerHTML += `
            <tr>

                <td>${room.room_number}</td>

                <td>${room.room_type}</td>

                <td>₹${room.price}</td>

                <td>${room.status}</td>

                <td>

                    <button
                        class="primary"
                        onclick="editRoom(${room.id})"
                    >
                        Edit
                    </button>

                    <button
                        class="danger"
                        onclick="deleteRoom(${room.id})"
                    >
                        Delete
                    </button>

                </td>

            </tr>
        `;
    });
}


// ===============================
// SEARCH ROOMS IN TABLE
// ===============================

function filterRooms() {

    const search =
        document
            .getElementById("roomSearch")
            .value
            .toLowerCase();

    const filtered =
        rooms.filter(room =>
            room.room_number
                .toLowerCase()
                .includes(search) ||
            room.room_type
                .toLowerCase()
                .includes(search)
        );

    displayRooms(filtered);
}


// ===============================
// ROOM MODAL
// ===============================

function openRoomModal() {

    document
        .getElementById("roomModal")
        .classList.remove("hidden");

    document
        .getElementById("roomForm")
        .reset();

    document
        .getElementById("roomId")
        .value = "";
}


function closeRoomModal() {

    document
        .getElementById("roomModal")
        .classList.add("hidden");
}


// ===============================
// ADD / UPDATE ROOM
// ===============================

document
    .getElementById("roomForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();

        const id =
            document.getElementById("roomId").value;

        const data = {

            room_number:
                document.getElementById("roomNumber").value,

            room_type:
                document.getElementById("roomType").value,

            price:
                Number(
                    document.getElementById("roomPrice").value
                ),

            status:
                document.getElementById("roomStatus").value
        };

        const url =
            id
                ? `/api/rooms/${id}`
                : "/api/rooms";

        const method =
            id ? "PUT" : "POST";

        const response =
            await fetch(url, {

                method,

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify(data)
            });

        const result =
            await response.json();

        if (!result.success) {

            showNotification(result.message);

            return;
        }

        showNotification(result.message);

        closeRoomModal();

        loadRooms();

        loadDashboard();
    });


// ===============================
// EDIT ROOM
// ===============================

function editRoom(id) {

    const room =
        rooms.find(room => room.id === id);

    if (!room) return;

    document
        .getElementById("roomId")
        .value = room.id;

    document
        .getElementById("roomNumber")
        .value = room.room_number;

    document
        .getElementById("roomType")
        .value = room.room_type;

    document
        .getElementById("roomPrice")
        .value = room.price;

    document
        .getElementById("roomStatus")
        .value = room.status;

    document
        .getElementById("roomModal")
        .classList.remove("hidden");
}


// ===============================
// DELETE ROOM
// ===============================

async function deleteRoom(id) {

    if (
        !confirm(
            "Are you sure you want to delete this room?"
        )
    ) {
        return;
    }

    const response =
        await fetch(`/api/rooms/${id}`, {
            method: "DELETE"
        });

    const result =
        await response.json();

    showNotification(result.message);

    if (result.success) {

        loadRooms();

        loadDashboard();
    }
}


// ===============================
// ROOM OPTIONS FOR BOOKING
// ===============================

async function loadRoomOptions() {

    const response =
        await fetch("/api/rooms");

    const result =
        await response.json();

    const select =
        document.getElementById("bookingRoom");

    select.innerHTML =
        `<option value="">Select Room</option>`;

    if (!result.success) return;

    result.data.forEach(room => {

        select.innerHTML += `
            <option value="${room.id}">
                ${room.room_number}
                - ${room.room_type}
                - ₹${room.price}
            </option>
        `;
    });
}


// ===============================
// SEARCH AVAILABLE ROOMS
// ===============================

async function searchAvailableRooms() {

    const type =
        document.getElementById("searchType").value;

    const checkIn =
        document.getElementById("searchCheckIn").value;

    const checkOut =
        document.getElementById("searchCheckOut").value;

    if (!checkIn || !checkOut) {

        showNotification(
            "Please select both dates"
        );

        return;
    }

    const params =
        new URLSearchParams({
            type,
            checkIn,
            checkOut
        });

    const response =
        await fetch(
            `/api/rooms/search?${params}`
        );

    const result =
        await response.json();

    const container =
        document.getElementById("searchResults");

    container.innerHTML = "";

    if (!result.success) {

        showNotification(result.message);

        return;
    }

    if (result.data.length === 0) {

        container.innerHTML =
            `<p>No rooms available.</p>`;

        return;
    }

    result.data.forEach(room => {

        container.innerHTML += `

            <div class="search-card">

                <h3>
                    Room ${room.room_number}
                </h3>

                <p>
                    Type: ${room.room_type}
                </p>

                <p>
                    Price: ₹${room.price} / night
                </p>

                <button
                    class="primary"
                    onclick="selectRoomForBooking(${room.id})"
                >
                    Book This Room
                </button>

            </div>

        `;
    });
}


// ===============================
// SELECT ROOM
// ===============================

function selectRoomForBooking(id) {

    showSection("booking");

    document
        .getElementById("bookingRoom")
        .value = id;
}


// ===============================
// BOOKING FORM
// ===============================

document
    .getElementById("bookingForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();

        const data = {

            guest_name:
                document.getElementById("guestName").value,

            guest_email:
                document.getElementById("guestEmail").value,

            guest_phone:
                document.getElementById("guestPhone").value,

            room_id:
                Number(
                    document.getElementById("bookingRoom").value
                ),

            check_in:
                document.getElementById("bookingCheckIn").value,

            check_out:
                document.getElementById("bookingCheckOut").value
        };


        const response =
            await fetch("/api/bookings", {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify(data)
            });


        const result =
            await response.json();


        if (!result.success) {

            showNotification(result.message);

            return;
        }


        showNotification(
            `Booking successful. Total: ₹${result.data.totalAmount}`
        );


        document
            .getElementById("bookingForm")
            .reset();


        loadDashboard();

        loadBookings();
    });


// ===============================
// BOOKINGS
// ===============================

async function loadBookings() {

    const search =
        document
            .getElementById("bookingSearch")
            .value;

    const response =
        await fetch(
            `/api/bookings?search=${encodeURIComponent(search)}`
        );

    const result =
        await response.json();

    if (!result.success) {

        showNotification(result.message);

        return;
    }

    const table =
        document.getElementById("bookingTable");

    table.innerHTML = "";


    result.data.forEach(booking => {

        table.innerHTML += `

            <tr>

                <td>${booking.id}</td>

                <td>${booking.guest_name}</td>

                <td>
                    ${booking.room_number}
                    (${booking.room_type})
                </td>

                <td>${booking.check_in}</td>

                <td>${booking.check_out}</td>

                <td>${booking.status}</td>

                <td>

                    ${
                        booking.status === "Confirmed"

                        ? `
                        <button
                            class="danger"
                            onclick="cancelBooking(${booking.id})"
                        >
                            Cancel
                        </button>
                        `

                        : "-"
                    }

                </td>

            </tr>

        `;
    });
}


// ===============================
// CANCEL BOOKING
// ===============================

async function cancelBooking(id) {

    if (
        !confirm(
            "Are you sure you want to cancel this booking?"
        )
    ) {
        return;
    }


    const response =
        await fetch(
            `/api/bookings/${id}/cancel`,
            {
                method: "POST"
            }
        );


    const result =
        await response.json();


    showNotification(result.message);


    if (result.success) {

        loadBookings();

        loadDashboard();
    }
}


// ===============================
// INITIAL LOAD
// ===============================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        loadDashboard();

        loadRooms();

        loadBookings();

    }
);